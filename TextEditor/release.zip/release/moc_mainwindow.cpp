/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[46];
    char stringdata0[1102];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(4, 59, 26), // "on_actionSave_as_triggered"
QT_MOC_LITERAL(5, 86, 24), // "on_actionPrint_triggered"
QT_MOC_LITERAL(6, 111, 23), // "on_actionExit_triggered"
QT_MOC_LITERAL(7, 135, 23), // "on_actionCopy_triggered"
QT_MOC_LITERAL(8, 159, 22), // "on_actionCut_triggered"
QT_MOC_LITERAL(9, 182, 17), // "clipboard_changed"
QT_MOC_LITERAL(10, 200, 11), // "fileChanged"
QT_MOC_LITERAL(11, 212, 20), // "showContextPasteMenu"
QT_MOC_LITERAL(12, 233, 3), // "pos"
QT_MOC_LITERAL(13, 237, 24), // "on_actionPaste_triggered"
QT_MOC_LITERAL(14, 262, 26), // "on_actionPaste_2_triggered"
QT_MOC_LITERAL(15, 289, 26), // "on_actionPaste_3_triggered"
QT_MOC_LITERAL(16, 316, 26), // "on_actionPaste_4_triggered"
QT_MOC_LITERAL(17, 343, 26), // "on_actionPaste_5_triggered"
QT_MOC_LITERAL(18, 370, 23), // "on_actionUndo_triggered"
QT_MOC_LITERAL(19, 394, 23), // "on_actionRedo_triggered"
QT_MOC_LITERAL(20, 418, 15), // "showContextMenu"
QT_MOC_LITERAL(21, 434, 26), // "on_actionZoom_in_triggered"
QT_MOC_LITERAL(22, 461, 27), // "on_actionZoom_Out_triggered"
QT_MOC_LITERAL(23, 489, 32), // "on_actionZoom_Standard_triggered"
QT_MOC_LITERAL(24, 522, 42), // "on_actionSplit_Dock_Horizonta..."
QT_MOC_LITERAL(25, 565, 26), // "on_tabWidget_tabBarClicked"
QT_MOC_LITERAL(26, 592, 5), // "index"
QT_MOC_LITERAL(27, 598, 37), // "on_actionView_Rendered_HTML_t..."
QT_MOC_LITERAL(28, 636, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(29, 660, 30), // "on_actionFormat_Text_triggered"
QT_MOC_LITERAL(30, 691, 23), // "on_actionBold_triggered"
QT_MOC_LITERAL(31, 715, 25), // "on_actionItalic_triggered"
QT_MOC_LITERAL(32, 741, 28), // "on_actionUnderline_triggered"
QT_MOC_LITERAL(33, 770, 34), // "on_fontComboBox_currentFontCh..."
QT_MOC_LITERAL(34, 805, 1), // "f"
QT_MOC_LITERAL(35, 807, 39), // "on_fontSizeComboBox_currentIn..."
QT_MOC_LITERAL(36, 847, 29), // "on_fontSizeComboBox_activated"
QT_MOC_LITERAL(37, 877, 4), // "arg1"
QT_MOC_LITERAL(38, 882, 26), // "on_actionOptions_triggered"
QT_MOC_LITERAL(39, 909, 25), // "on_actionCenter_triggered"
QT_MOC_LITERAL(40, 935, 29), // "on_actionAlign_Left_triggered"
QT_MOC_LITERAL(41, 965, 30), // "on_actionAlign_Right_triggered"
QT_MOC_LITERAL(42, 996, 25), // "on_actionSave_2_triggered"
QT_MOC_LITERAL(43, 1022, 26), // "on_actionBullets_triggered"
QT_MOC_LITERAL(44, 1049, 28), // "on_actionNumbering_triggered"
QT_MOC_LITERAL(45, 1078, 23) // "on_actionFind_triggered"

    },
    "MainWindow\0on_actionNew_triggered\0\0"
    "on_actionOpen_triggered\0"
    "on_actionSave_as_triggered\0"
    "on_actionPrint_triggered\0"
    "on_actionExit_triggered\0on_actionCopy_triggered\0"
    "on_actionCut_triggered\0clipboard_changed\0"
    "fileChanged\0showContextPasteMenu\0pos\0"
    "on_actionPaste_triggered\0"
    "on_actionPaste_2_triggered\0"
    "on_actionPaste_3_triggered\0"
    "on_actionPaste_4_triggered\0"
    "on_actionPaste_5_triggered\0"
    "on_actionUndo_triggered\0on_actionRedo_triggered\0"
    "showContextMenu\0on_actionZoom_in_triggered\0"
    "on_actionZoom_Out_triggered\0"
    "on_actionZoom_Standard_triggered\0"
    "on_actionSplit_Dock_Horizontally_triggered\0"
    "on_tabWidget_tabBarClicked\0index\0"
    "on_actionView_Rendered_HTML_triggered\0"
    "on_actionSave_triggered\0"
    "on_actionFormat_Text_triggered\0"
    "on_actionBold_triggered\0"
    "on_actionItalic_triggered\0"
    "on_actionUnderline_triggered\0"
    "on_fontComboBox_currentFontChanged\0f\0"
    "on_fontSizeComboBox_currentIndexChanged\0"
    "on_fontSizeComboBox_activated\0arg1\0"
    "on_actionOptions_triggered\0"
    "on_actionCenter_triggered\0"
    "on_actionAlign_Left_triggered\0"
    "on_actionAlign_Right_triggered\0"
    "on_actionSave_2_triggered\0"
    "on_actionBullets_triggered\0"
    "on_actionNumbering_triggered\0"
    "on_actionFind_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      40,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  214,    2, 0x08 /* Private */,
       3,    0,  215,    2, 0x08 /* Private */,
       4,    0,  216,    2, 0x08 /* Private */,
       5,    0,  217,    2, 0x08 /* Private */,
       6,    0,  218,    2, 0x08 /* Private */,
       7,    0,  219,    2, 0x08 /* Private */,
       8,    0,  220,    2, 0x08 /* Private */,
       9,    0,  221,    2, 0x08 /* Private */,
      10,    0,  222,    2, 0x08 /* Private */,
      11,    1,  223,    2, 0x08 /* Private */,
      13,    0,  226,    2, 0x08 /* Private */,
      14,    0,  227,    2, 0x08 /* Private */,
      15,    0,  228,    2, 0x08 /* Private */,
      16,    0,  229,    2, 0x08 /* Private */,
      17,    0,  230,    2, 0x08 /* Private */,
      18,    0,  231,    2, 0x08 /* Private */,
      19,    0,  232,    2, 0x08 /* Private */,
      20,    1,  233,    2, 0x08 /* Private */,
      21,    0,  236,    2, 0x08 /* Private */,
      22,    0,  237,    2, 0x08 /* Private */,
      23,    0,  238,    2, 0x08 /* Private */,
      24,    0,  239,    2, 0x08 /* Private */,
      25,    1,  240,    2, 0x08 /* Private */,
      27,    0,  243,    2, 0x08 /* Private */,
      28,    0,  244,    2, 0x08 /* Private */,
      29,    0,  245,    2, 0x08 /* Private */,
      30,    0,  246,    2, 0x08 /* Private */,
      31,    0,  247,    2, 0x08 /* Private */,
      32,    0,  248,    2, 0x08 /* Private */,
      33,    1,  249,    2, 0x08 /* Private */,
      35,    1,  252,    2, 0x08 /* Private */,
      36,    1,  255,    2, 0x08 /* Private */,
      38,    0,  258,    2, 0x08 /* Private */,
      39,    0,  259,    2, 0x08 /* Private */,
      40,    0,  260,    2, 0x08 /* Private */,
      41,    0,  261,    2, 0x08 /* Private */,
      42,    0,  262,    2, 0x08 /* Private */,
      43,    0,  263,    2, 0x08 /* Private */,
      44,    0,  264,    2, 0x08 /* Private */,
      45,    0,  265,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QFont,   34,
    QMetaType::Void, QMetaType::Int,   26,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_actionNew_triggered(); break;
        case 1: _t->on_actionOpen_triggered(); break;
        case 2: _t->on_actionSave_as_triggered(); break;
        case 3: _t->on_actionPrint_triggered(); break;
        case 4: _t->on_actionExit_triggered(); break;
        case 5: _t->on_actionCopy_triggered(); break;
        case 6: _t->on_actionCut_triggered(); break;
        case 7: _t->clipboard_changed(); break;
        case 8: _t->fileChanged(); break;
        case 9: _t->showContextPasteMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 10: _t->on_actionPaste_triggered(); break;
        case 11: _t->on_actionPaste_2_triggered(); break;
        case 12: _t->on_actionPaste_3_triggered(); break;
        case 13: _t->on_actionPaste_4_triggered(); break;
        case 14: _t->on_actionPaste_5_triggered(); break;
        case 15: _t->on_actionUndo_triggered(); break;
        case 16: _t->on_actionRedo_triggered(); break;
        case 17: _t->showContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 18: _t->on_actionZoom_in_triggered(); break;
        case 19: _t->on_actionZoom_Out_triggered(); break;
        case 20: _t->on_actionZoom_Standard_triggered(); break;
        case 21: _t->on_actionSplit_Dock_Horizontally_triggered(); break;
        case 22: _t->on_tabWidget_tabBarClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: _t->on_actionView_Rendered_HTML_triggered(); break;
        case 24: _t->on_actionSave_triggered(); break;
        case 25: _t->on_actionFormat_Text_triggered(); break;
        case 26: _t->on_actionBold_triggered(); break;
        case 27: _t->on_actionItalic_triggered(); break;
        case 28: _t->on_actionUnderline_triggered(); break;
        case 29: _t->on_fontComboBox_currentFontChanged((*reinterpret_cast< const QFont(*)>(_a[1]))); break;
        case 30: _t->on_fontSizeComboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->on_fontSizeComboBox_activated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 32: _t->on_actionOptions_triggered(); break;
        case 33: _t->on_actionCenter_triggered(); break;
        case 34: _t->on_actionAlign_Left_triggered(); break;
        case 35: _t->on_actionAlign_Right_triggered(); break;
        case 36: _t->on_actionSave_2_triggered(); break;
        case 37: _t->on_actionBullets_triggered(); break;
        case 38: _t->on_actionNumbering_triggered(); break;
        case 39: _t->on_actionFind_triggered(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 40)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 40;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 40)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 40;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
